#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 * This program prints string text.
 * 
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Used and Modified with permission by Julian Amrine.
 * Date: 14 May 2016
**/

int main(int argc, char *argv[]) {
  cout << "Hello, world." << endl;
  cout << "My name is Julian Amrine." << endl;

  return 0;
}
